# ROS 2 connext filler package

Trivial package to satisfy rmw_connext dependencies on arm64 for the ROS 2 buildfarm.
This package contains no RTI sources or DDS implementation.

