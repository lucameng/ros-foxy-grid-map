// generated from rosidl_generator_c/resource/idl.h.em
// with input from test_msgs:action/NestedMessage.idl
// generated code does not contain a copyright notice

#ifndef TEST_MSGS__ACTION__NESTED_MESSAGE_H_
#define TEST_MSGS__ACTION__NESTED_MESSAGE_H_

#include "test_msgs/action/detail/nested_message__struct.h"
#include "test_msgs/action/detail/nested_message__functions.h"
#include "test_msgs/action/detail/nested_message__type_support.h"

#endif  // TEST_MSGS__ACTION__NESTED_MESSAGE_H_
