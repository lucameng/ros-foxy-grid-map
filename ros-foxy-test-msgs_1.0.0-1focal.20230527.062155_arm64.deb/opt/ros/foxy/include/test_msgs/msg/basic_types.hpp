// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TEST_MSGS__MSG__BASIC_TYPES_HPP_
#define TEST_MSGS__MSG__BASIC_TYPES_HPP_

#include "test_msgs/msg/detail/basic_types__struct.hpp"
#include "test_msgs/msg/detail/basic_types__builder.hpp"
#include "test_msgs/msg/detail/basic_types__traits.hpp"
#include "test_msgs/msg/detail/basic_types__type_support.hpp"

#endif  // TEST_MSGS__MSG__BASIC_TYPES_HPP_
