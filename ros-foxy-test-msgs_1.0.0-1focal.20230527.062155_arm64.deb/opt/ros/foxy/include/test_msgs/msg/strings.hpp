// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TEST_MSGS__MSG__STRINGS_HPP_
#define TEST_MSGS__MSG__STRINGS_HPP_

#include "test_msgs/msg/detail/strings__struct.hpp"
#include "test_msgs/msg/detail/strings__builder.hpp"
#include "test_msgs/msg/detail/strings__traits.hpp"
#include "test_msgs/msg/detail/strings__type_support.hpp"

#endif  // TEST_MSGS__MSG__STRINGS_HPP_
