// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TEST_MSGS__MSG__DEFAULTS_HPP_
#define TEST_MSGS__MSG__DEFAULTS_HPP_

#include "test_msgs/msg/detail/defaults__struct.hpp"
#include "test_msgs/msg/detail/defaults__builder.hpp"
#include "test_msgs/msg/detail/defaults__traits.hpp"
#include "test_msgs/msg/detail/defaults__type_support.hpp"

#endif  // TEST_MSGS__MSG__DEFAULTS_HPP_
