// generated from rosidl_generator_c/resource/idl.h.em
// with input from octomap_msgs:srv/BoundingBoxQuery.idl
// generated code does not contain a copyright notice

#ifndef OCTOMAP_MSGS__SRV__BOUNDING_BOX_QUERY_H_
#define OCTOMAP_MSGS__SRV__BOUNDING_BOX_QUERY_H_

#include "octomap_msgs/srv/detail/bounding_box_query__struct.h"
#include "octomap_msgs/srv/detail/bounding_box_query__functions.h"
#include "octomap_msgs/srv/detail/bounding_box_query__type_support.h"

#endif  // OCTOMAP_MSGS__SRV__BOUNDING_BOX_QUERY_H_
