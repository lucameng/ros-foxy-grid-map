// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef OCTOMAP_MSGS__SRV__BOUNDING_BOX_QUERY_HPP_
#define OCTOMAP_MSGS__SRV__BOUNDING_BOX_QUERY_HPP_

#include "octomap_msgs/srv/detail/bounding_box_query__struct.hpp"
#include "octomap_msgs/srv/detail/bounding_box_query__builder.hpp"
#include "octomap_msgs/srv/detail/bounding_box_query__traits.hpp"
#include "octomap_msgs/srv/detail/bounding_box_query__type_support.hpp"

#endif  // OCTOMAP_MSGS__SRV__BOUNDING_BOX_QUERY_HPP_
