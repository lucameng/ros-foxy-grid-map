// generated from rosidl_generator_c/resource/idl.h.em
// with input from octomap_msgs:msg/Octomap.idl
// generated code does not contain a copyright notice

#ifndef OCTOMAP_MSGS__MSG__OCTOMAP_H_
#define OCTOMAP_MSGS__MSG__OCTOMAP_H_

#include "octomap_msgs/msg/detail/octomap__struct.h"
#include "octomap_msgs/msg/detail/octomap__functions.h"
#include "octomap_msgs/msg/detail/octomap__type_support.h"

#endif  // OCTOMAP_MSGS__MSG__OCTOMAP_H_
