// generated from rosidl_generator_c/resource/idl.h.em
// with input from octomap_msgs:msg/OctomapWithPose.idl
// generated code does not contain a copyright notice

#ifndef OCTOMAP_MSGS__MSG__OCTOMAP_WITH_POSE_H_
#define OCTOMAP_MSGS__MSG__OCTOMAP_WITH_POSE_H_

#include "octomap_msgs/msg/detail/octomap_with_pose__struct.h"
#include "octomap_msgs/msg/detail/octomap_with_pose__functions.h"
#include "octomap_msgs/msg/detail/octomap_with_pose__type_support.h"

#endif  // OCTOMAP_MSGS__MSG__OCTOMAP_WITH_POSE_H_
