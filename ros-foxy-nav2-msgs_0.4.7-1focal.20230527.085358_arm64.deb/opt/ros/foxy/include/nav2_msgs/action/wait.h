// generated from rosidl_generator_c/resource/idl.h.em
// with input from nav2_msgs:action/Wait.idl
// generated code does not contain a copyright notice

#ifndef NAV2_MSGS__ACTION__WAIT_H_
#define NAV2_MSGS__ACTION__WAIT_H_

#include "nav2_msgs/action/detail/wait__struct.h"
#include "nav2_msgs/action/detail/wait__functions.h"
#include "nav2_msgs/action/detail/wait__type_support.h"

#endif  // NAV2_MSGS__ACTION__WAIT_H_
