// generated from rosidl_generator_c/resource/idl.h.em
// with input from nav2_msgs:action/DummyRecovery.idl
// generated code does not contain a copyright notice

#ifndef NAV2_MSGS__ACTION__DUMMY_RECOVERY_H_
#define NAV2_MSGS__ACTION__DUMMY_RECOVERY_H_

#include "nav2_msgs/action/detail/dummy_recovery__struct.h"
#include "nav2_msgs/action/detail/dummy_recovery__functions.h"
#include "nav2_msgs/action/detail/dummy_recovery__type_support.h"

#endif  // NAV2_MSGS__ACTION__DUMMY_RECOVERY_H_
