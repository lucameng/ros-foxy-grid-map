// generated from rosidl_generator_c/resource/idl.h.em
// with input from nav2_msgs:action/Spin.idl
// generated code does not contain a copyright notice

#ifndef NAV2_MSGS__ACTION__SPIN_H_
#define NAV2_MSGS__ACTION__SPIN_H_

#include "nav2_msgs/action/detail/spin__struct.h"
#include "nav2_msgs/action/detail/spin__functions.h"
#include "nav2_msgs/action/detail/spin__type_support.h"

#endif  // NAV2_MSGS__ACTION__SPIN_H_
