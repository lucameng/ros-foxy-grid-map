// generated from rosidl_generator_c/resource/idl.h.em
// with input from nav2_msgs:srv/ClearCostmapExceptRegion.idl
// generated code does not contain a copyright notice

#ifndef NAV2_MSGS__SRV__CLEAR_COSTMAP_EXCEPT_REGION_H_
#define NAV2_MSGS__SRV__CLEAR_COSTMAP_EXCEPT_REGION_H_

#include "nav2_msgs/srv/detail/clear_costmap_except_region__struct.h"
#include "nav2_msgs/srv/detail/clear_costmap_except_region__functions.h"
#include "nav2_msgs/srv/detail/clear_costmap_except_region__type_support.h"

#endif  // NAV2_MSGS__SRV__CLEAR_COSTMAP_EXCEPT_REGION_H_
