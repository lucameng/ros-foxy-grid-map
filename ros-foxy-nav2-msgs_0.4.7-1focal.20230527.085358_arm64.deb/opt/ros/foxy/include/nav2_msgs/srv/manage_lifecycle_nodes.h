// generated from rosidl_generator_c/resource/idl.h.em
// with input from nav2_msgs:srv/ManageLifecycleNodes.idl
// generated code does not contain a copyright notice

#ifndef NAV2_MSGS__SRV__MANAGE_LIFECYCLE_NODES_H_
#define NAV2_MSGS__SRV__MANAGE_LIFECYCLE_NODES_H_

#include "nav2_msgs/srv/detail/manage_lifecycle_nodes__struct.h"
#include "nav2_msgs/srv/detail/manage_lifecycle_nodes__functions.h"
#include "nav2_msgs/srv/detail/manage_lifecycle_nodes__type_support.h"

#endif  // NAV2_MSGS__SRV__MANAGE_LIFECYCLE_NODES_H_
