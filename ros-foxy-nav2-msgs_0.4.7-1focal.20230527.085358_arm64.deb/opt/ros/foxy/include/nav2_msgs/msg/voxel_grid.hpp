// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef NAV2_MSGS__MSG__VOXEL_GRID_HPP_
#define NAV2_MSGS__MSG__VOXEL_GRID_HPP_

#include "nav2_msgs/msg/detail/voxel_grid__struct.hpp"
#include "nav2_msgs/msg/detail/voxel_grid__builder.hpp"
#include "nav2_msgs/msg/detail/voxel_grid__traits.hpp"
#include "nav2_msgs/msg/detail/voxel_grid__type_support.hpp"

#endif  // NAV2_MSGS__MSG__VOXEL_GRID_HPP_
