// generated from rosidl_generator_c/resource/idl.h.em
// with input from nav2_msgs:msg/BehaviorTreeStatusChange.idl
// generated code does not contain a copyright notice

#ifndef NAV2_MSGS__MSG__BEHAVIOR_TREE_STATUS_CHANGE_H_
#define NAV2_MSGS__MSG__BEHAVIOR_TREE_STATUS_CHANGE_H_

#include "nav2_msgs/msg/detail/behavior_tree_status_change__struct.h"
#include "nav2_msgs/msg/detail/behavior_tree_status_change__functions.h"
#include "nav2_msgs/msg/detail/behavior_tree_status_change__type_support.h"

#endif  // NAV2_MSGS__MSG__BEHAVIOR_TREE_STATUS_CHANGE_H_
