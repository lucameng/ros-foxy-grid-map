// generated from rosidl_generator_c/resource/idl.h.em
// with input from nav2_msgs:msg/CostmapMetaData.idl
// generated code does not contain a copyright notice

#ifndef NAV2_MSGS__MSG__COSTMAP_META_DATA_H_
#define NAV2_MSGS__MSG__COSTMAP_META_DATA_H_

#include "nav2_msgs/msg/detail/costmap_meta_data__struct.h"
#include "nav2_msgs/msg/detail/costmap_meta_data__functions.h"
#include "nav2_msgs/msg/detail/costmap_meta_data__type_support.h"

#endif  // NAV2_MSGS__MSG__COSTMAP_META_DATA_H_
