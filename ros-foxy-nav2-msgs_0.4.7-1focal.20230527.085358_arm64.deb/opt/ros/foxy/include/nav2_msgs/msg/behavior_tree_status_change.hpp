// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef NAV2_MSGS__MSG__BEHAVIOR_TREE_STATUS_CHANGE_HPP_
#define NAV2_MSGS__MSG__BEHAVIOR_TREE_STATUS_CHANGE_HPP_

#include "nav2_msgs/msg/detail/behavior_tree_status_change__struct.hpp"
#include "nav2_msgs/msg/detail/behavior_tree_status_change__builder.hpp"
#include "nav2_msgs/msg/detail/behavior_tree_status_change__traits.hpp"
#include "nav2_msgs/msg/detail/behavior_tree_status_change__type_support.hpp"

#endif  // NAV2_MSGS__MSG__BEHAVIOR_TREE_STATUS_CHANGE_HPP_
